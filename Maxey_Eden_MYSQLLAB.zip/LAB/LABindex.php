<html>
<center>
<form action = "LABdatabase.php" method = "post">
	<h1>Sign Guestbook</h1>
	Name: <input type = "text" name = "name" value = "Sleve" required>
	<br>
	Email: <input type = "text" name = "email" value = "McDichael">
	<br>
	Date: <input type = "date" name = "date">
	<br>
	Message: <input type = "text" name = "message" value = "Yo.">
	<br>
	<input type="submit" value="Submit">
	<input type = "reset" value = "Reset">
	<br>
	<br>
	<a href = "LABdatabase.php">View Guestbook</a>
</form>