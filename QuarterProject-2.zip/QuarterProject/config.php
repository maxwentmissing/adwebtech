<?php
        //template with all the code needed to connect to the server  
		$dbhost = 'localhost';
         $dbuser = 'root';
         $dbpass =  '';
         $conn = mysqli_connect($dbhost, $dbuser, $dbpass);

?> 