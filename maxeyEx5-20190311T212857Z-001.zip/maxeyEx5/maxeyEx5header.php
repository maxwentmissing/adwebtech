<!--Eden Maxey April 12 2018-->
<html>
<head>
<style>
body {
	color : #c0a7ef;
	background-color: #dce5ea;
	text-align: center;
	font-family: Arial;
}

ul{
	list-style-type:none;
	overflow: hidden;
	background-color: #eae3f7;

}

li{
	float: center;
}

li a{
	display: inline-block;
	color: #ad91e2;
	text-align: center;
	padding: 15px;
	font-size: 25px;
	text-decoration:none;

	
}

li a:hover{
	background-color: #ad91e2;
	color: #eae3f7;
}

hr{
	border-width: 3px;
}
</style>
</head>

<body>
<center>
<?php
echo "<h1>Welcome to my Wonderful WebPage!</h1>";
echo "<ul><li class = 'menu'>
		<a class = 'active' href = 'https://www.youtube.com/watch?v=MwmeCp0MqSQ'>  Funny Video!  </a>
		<a class = 'active' href = 'https://www.newgrounds.com/'>  Old Memes  </a>
		<a class = 'active' href = 'https://www.themessyheads.com/'>  Artsy Blog  </a>
		<a class = 'active' href = 'https://www.boredpanda.com/art-history-memes/?page_numb=19&utm_content=inf_10_2558_2&utm_source=facebook&utm_medium=link&utm_campaign=socialedge'>  New Old Memes  </a>
		<a class = 'active' href = 'https://www.artformplatform.com/'>  All Encompassing Art  </a>
		<a class = 'active' href = 'http://www.sakana-comic.com/comic/title-page-vol-1'>  Fish Comic!  </a> 
	</ul><br><hr>";
?>
</body>
</html>