<html>
<center>
<form action = "database.php" method = "post">
	First Name: <input type = "text" name = "fname">
	<br>
	Last Name: <input type = "text" name = "lname">
	<br>
	Test Date: <input type = "date" name = "date">
	<br>
	Score: <input type = "number" name = "score">
	<br>
	<input type="submit" value="Submit">
</form>