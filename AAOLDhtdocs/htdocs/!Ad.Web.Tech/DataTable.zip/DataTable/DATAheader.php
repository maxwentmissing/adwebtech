<html lang="en">
<head>
  <title>Rad</title>
  
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
  <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
  <script src ="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
  <link rel="stylesheet" href="DATAheadercss.css" media="screen">
  <link rel="stylesheet" href="DATAbodycss.css" media="screen">
  
  <link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css">
  
  <link rel = "icon" href = "icon.gif">
  <audio autoplay = "true" src = "???"></audio>
</head>


<body>
<!--top head part-->
<div class = "header">
	<!--image over bg; "hella rad" equivalent-->
</div>
<!--navbar-->
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
    </div>
	
    <div class="collapse navbar-collapse" id="myNavbar">
      
	  <ul class="nav navbar-nav">
        <li><a href="DATAhtml.php"><p>HTML</p></a></li>
		<li><a href="DATAsql.php"><p>SQL</p></a></li>
      </ul>
	  
      <ul class="nav navbar-nav navbar-right">
        <li><a href="cachemonet.com"><span class="glyphicon glyphicon-heart-empty"></span></a></li>
        <li><a href="beesbeesbees.com"><span class="glyphicon glyphicon-piggy-bank"></span></a></li>
      </ul>
    </div>
  </div>
</nav>
<!--End Nav-->
</body>
</html>