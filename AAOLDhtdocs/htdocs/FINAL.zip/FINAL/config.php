<?php
$databaseHost = 'localhost';
$databaseUsername = 'root';
$databasePassword = '';

$conn = mysqli_connect($databaseHost, $databaseUsername, $databasePassword);

/*if(!$conn){
	die("connection failed: " . mysqli_connect_error());
}

echo "Connected successfully";*/

?>