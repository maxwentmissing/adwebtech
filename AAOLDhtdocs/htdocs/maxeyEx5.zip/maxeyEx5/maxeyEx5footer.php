<!--Eden Maxey April 12 2018-->
<html>
<head>
<style>
body {
	color : #c0a7ef;
	background-color: #dce5ea;
	text-align: center;
	font-family: Arial;
}

hr{
	border-width: 3px;
}

</style>
</head>

<body>
<center>
<?php
echo "<hr>copyright me or whateve, with stuff copy and pasted frm w3schools";
?>
</body>
</html>